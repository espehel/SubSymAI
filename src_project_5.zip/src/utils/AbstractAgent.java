package utils;

/**
 * Created by espen on 06/05/15.
 */
public abstract class AbstractAgent {
    public Direction front;
    public int x;
    public int y;
}
