package ann.problems.tracker;

/**
 * Created by espen on 14/04/15.
 */
public class FallingBlock extends BlockObject {



    public FallingBlock(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }

    public FallingBlock() {
    }

    public void reset(int x, int y, int size) {
        this.x = x;
        this.y = y;
        this.size = size;
    }
}
