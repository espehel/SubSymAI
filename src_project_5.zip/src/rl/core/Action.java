package rl.core;

import utils.Direction;

/**
 * Created by espen on 07/05/15.
 */
public class Action {

}
