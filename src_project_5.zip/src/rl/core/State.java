package rl.core;

/**
 * Created by espen on 07/05/15.
 */
public class State {
    public double eligibility = 0;
}
