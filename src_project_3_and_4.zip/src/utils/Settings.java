package utils;


/**
 * Created by espen on 02/04/15.
 */
public class Settings {
    public static ann.core.Settings ann;
    public static ea.core.Settings ea;
}
