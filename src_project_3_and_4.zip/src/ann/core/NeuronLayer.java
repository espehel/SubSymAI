package ann.core;

/**
 * Created by espen on 02/04/15.
 */
public class NeuronLayer {

    public Neuron[] neurons;

}
